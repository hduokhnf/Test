chạy code bằng php nhé

php 11.8.php
